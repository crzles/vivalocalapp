// Function to redirect to the second page
function fourthPage(){
      window.location.href = 'fourthpage.html'; // Correctly redirects to the second page
  }
function secondPage(){
      window.location.href = 'secondpage.html'; // Correctly redirects to the second page
  }
// function thirdPage(){
//     window.location.href = 'thirdpage.html'; 
// }
